﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookShopDB.Model.Enums
{
    public enum AgeRestriction
    {
        Minor = 0, 
        Teen = 1,
        Adult = 2
    }
}
