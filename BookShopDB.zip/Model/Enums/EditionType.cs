﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookShopDB.Model.Enums
{
    public enum EditionType
    {
        Normal = 0, 
        Promo = 1,
        Gold = 2
    }
}
