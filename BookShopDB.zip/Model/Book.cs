﻿using BookShopDB.Model.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace BookShopDB.Model
{
    public class Book
    {
        
        public int BookId { get; set; }
        public string Title { get; set; }
        [MaxLength(1000)]
        public string  Description { get; set; }
        public DateTime? ReleaseDate { get; set; }

        public decimal Price { get; set; }

        public int Copies { get; set; }        

        public EditionType EditionType { get; set; }

        public  AgeRestriction AgeRestriction { get; set; }

        public int AuthorId { get; set; }
        public Author Author { get; set; }

        public int CategoryId { get; set; }
        public Category Category { get; set; }

        public int BookCategoryId { get; set; }
        public BookCategory BookCathegory { get; set; }

        public ICollection<BookCategory> BookCategories { get; set; }

    }
}
