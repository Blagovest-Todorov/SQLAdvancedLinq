﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace BookShopDB.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
              @"Server=.;Database=MusicHub;Integrated Security=true";       

    }
}
