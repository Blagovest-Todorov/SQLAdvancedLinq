﻿namespace BookShopDB.Initializer
{

    using System;
    using System.Linq;
    using System.Reflection;
    using System.Collections.Generic;

    using Newtonsoft.Json;
    using Newtonsoft.Json.Linq;

    using Data;
    using BookShopDB.Model;
    using Microsoft.EntityFrameworkCore;

    public class DbInitializer
    {
        public static void ResetDatabase(BookShopContext context)
        {
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            Console.WriteLine("MusicHub database created successfully.");

            Seed(context);
        }

        private static void Seed(BookShopContext context)
        {
            var datasetsJson =
            "{\"Author\":[{\"Id\":1,\"FirstName\":\"Mik\",\"LastName\":\"Mikeloto\"},{\"Id\":2,\"Name\":\"Maitilde\",\"LastName\":\"Sangar\"},{\"Id\":3,\"FirstName\":\"Linnie\",\"LastName\":\"Petrolli\"},{\"Id\":4,\"FirstName\":\"Bili\",\"LastName\":\"Franek\"},{\"Id\":5,\"FirstName\":\"Quillan\",\"LastName\":\"Grover\"}],\"Book\":[{\"Id\":1,\"Title\":\"PipiLongStocks\",\"Description\":null,\"ReleaseDate\":\"2019-03-05T00:00:00\",\"Price\":19.5746,\"Copies\":1,\"EditionType\":0,\"AgeRegistration\":0,\"AuthorId\":1,\"CategoryId\":1}, {\"Id\":2,\"Title\":\"Pipi\",\"Description\":null,\"ReleaseDate\":\"2018-01-05T00:00:00\",\"Price\":10.5746,\"Copies\":1,\"EditionType\":0,\"AgeRegistration\":1,\"AuthorId\":2,\"CategoryId\":1}, {\"Id\":3,\"Title\":\"Bibi\",\"Description\":null,\"ReleaseDate\":\"2010-01-05T00:00:00\",\"Price\":9.5746,\"Copies\":2,\"EditionType\":1,\"AgeRegistration\":2,\"AuthorId\":3,\"CategoryId\":3},{\"Id\":4,\"Title\":\"ipi\",\"Description\":null,\"ReleaseDate\":\"2016-01-05T00:00:00\",\"Price\":10.5746,\"Copies\":1,\"EditionType\":0,\"AgeRegistration\":1,\"AuthorId\":4,\"CategoryId\":1},{\"Id\":5,\"Title\":\"Fifi\",\"Description\":null,\"ReleaseDate\":\"2022-01-05T00:00:00\",\"Price\":100.5746,\"Copies\":1,\"EditionType\":0,\"AgeRegistration\":1,\"AuthorId\":5,\"CategoryId\":1,\"BookCategory\":1}],\"Category\":[{\"Id\":1,\"Name\":\"Fight and flight\"},{\"Id\":2,\"Name\":\"Cherry\",\"BookCategoryId\":2},{\"Id\":3,\"Name\":\"No history\",\"BookCategory\":3},{\"Id\":3,\"Name\":\"Blinded by fame\",\"BookCategoryId\":3},{\"Id\":4,\"Name\":\"Barrage of noise\",\"BookCategory\":4},{\"Id\":5,\"Name\":\"The fat lady sings\",\"BookCategoryId\":5}],\"BookCategory\":[{\"BookId\":1,\"CategoryId\":1},{\"BookId\":2,\"CategoryId\":1},{\"BookId\":3,\"CategoryId\":2},{\"BookId\":4,\"CategoryId\":2},{\"BookId\":5]}";

            var datasets = JsonConvert.DeserializeObject<Dictionary<string, IEnumerable<JObject>>>(datasetsJson);

            foreach (var dataset in datasets)
            {
                var entityType = GetType(dataset.Key);

                using (var transaction = context.Database.BeginTransaction())
                {
                    var entities = dataset.Value
                        .Select(j => j.ToObject(entityType))
                        .ToArray();
                    var entityName = $"{entityType.Name}s";
                    context.AddRange(entities);

                    if (entityType != typeof(BookCategory))
                    {
                        context.Database.ExecuteSqlRaw("SET IDENTITY_INSERT " + entityName + " ON;");
                    }

                    context.SaveChanges();

                    if (entityType != typeof(BookCategory))
                    {
                        context.Database.ExecuteSqlRaw("SET IDENTITY_INSERT " + entityName + "  OFF;");
                    }
                    transaction.Commit();
                }
            }
        }

        private static Type GetType(string modelName)
        {
            var modelType = Assembly
                .GetEntryAssembly()?
                .GetTypes()
                .FirstOrDefault(t => t.Name == modelName);

            return modelType;
        }

    }
}
